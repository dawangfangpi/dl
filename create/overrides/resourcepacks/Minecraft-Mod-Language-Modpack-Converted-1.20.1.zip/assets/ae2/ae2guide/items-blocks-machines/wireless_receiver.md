---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 无线接收器
  icon: wireless_receiver
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:wireless_receiver
---

# 无线接收器

<ItemImage id="wireless_receiver" scale="4" />

置于反射碟中的<ItemLink id="fluix_pearl" />，是一种短距离无线ME科技组件。

## 配方

<RecipeFor id="wireless_receiver" />
